/*
 * Block template
 */
class Block {
  /*
 * x and y are the starting coordinates
 * ang is the starting angle
 */
  constructor(x, y, ang) {
    //Picks a random blocktype from the blockTypes array
    if (blocks.length < 1) {
      this.currentBlockType = blockTypes[Math.floor(random(0, blockTypes.length))];
    } else {
    this.currentBlockType = blocks[blocks.length-1].nextBlockType;
    }
    this.nextBlockType = blockTypes[Math.floor(random(0, blockTypes.length))];
    console.log(this.currentBlockType);
    blockAmount++;
    this.x = x;
    this.y = y;
    this.rotAngle = ang;
    this.activeBlock = true;
  }
  /*
  * Drawing and rotating block based on blocktype picked
  * angle is the given angle to draw
  */
  draw(angle) {
    push();
    //setting the block's x and y as origin
    translate(this.x, this.y);
    rotate(angle);
    fill(0);
    noStroke();
    //If the randomly picked blocktype is _, Draw this set of rectangles
    if (this.currentBlockType === "I") {
      push();
      fill(0, 255, 153);
      rect(0, 0, 20, 20);
      rect(0, 20, 20, 20);
      rect(0, 40, 20, 20);
      rect(0, 60, 20, 20);
      pop();
    } else if (this.currentBlockType === "O") {
      push();
      fill(255, 204, 0);
      rect(0, 0, 40, 40);
      rect(0, 0, 40, 20);
      pop();
    } else if (this.currentBlockType === "T") {
      push();
      fill(153, 0, 153);
      rect(0, 20, 20, 20);
      rect(-20, 0, 60, 20);
      pop();
    } else if (this.currentBlockType === "S") {
      push();
      fill(0, 204, 0);
      rect(-20, 0, 40, 20);
      rect(0, 20, 20, 20);
      rect(-20, -20, 20, 20);
      pop();
    } else if (this.currentBlockType === "Z") {
      push();
      fill(255, 0, 0);
      rect(0, 0, 40, 20);
      rect(0, 20, 20, 20);
      rect(20, -20, 20, 20);
      pop();
    } else if (this.currentBlockType === "J") {
      push();
      fill(0, 0, 255);
      rect(-20, 40, 40, 20);
      rect(0, 0, 20, 20);
      rect(0, 20, 20, 20);
      pop();
    } else if (this.currentBlockType === "L") {
      push();
      fill(255, 153, 0);
      rect(0, 40, 40, 20);
      rect(0, 0, 20, 20);
      rect(0, 20, 20, 20);
      pop();
    }
    pop();
  }
  /*
  * Boundaries for the current block
  */
  defineBoundaries() {
    if (this.activeBlock === true) {
    //SIDE BOUNDARIES

    //ROTATION 0
    //LEFT SIDE
    if (this.x < 30 && rotation === 0) {
      this.x = 30;
    } else if (this.currentBlockType === "S" && this.x < 50 && rotation === 0) {
      this.x = 50;
    } else if (this.currentBlockType === "J" && this.x < 50 && rotation === 0) {
      this.x = 50;
    } else if (this.currentBlockType === "T" && this.x < 50 && rotation === 0) {
      this.x = 50;
    }
    
    //ROTATION 1
    if (this.x < 90 && rotation === 1 &&  (this.currentBlockType === "L" || this.currentBlockType === "J")) {
      this.x = 90;
    } else if (this.x < 70 && rotation === 1 &&  this.currentBlockType === "O") {
      this.x = 70;
    } else if (this.x < 70 && rotation === 1 &&  (this.currentBlockType === "Z" || this.currentBlockType === "S")) {
      this.x = 70;
    } else if (this.x < 70 && rotation === 1 &&  this.currentBlockType === "T") {
      this.x = 70;
    } else if (this.x < 110 && rotation === 1 &&  this.currentBlockType === "I") {
      this.x = 110;
    }
    
    //ROTATION 2
    if (this.x < 30 && rotation === 2) {
      this.x = 30;
    } else if (this.currentBlockType === "S" && this.x < 50 && rotation === 2) {
      this.x = 50;
    } else if (this.currentBlockType === "Z" && this.x < 70 && rotation === 2) {
      this.x = 70;
    } else if (this.currentBlockType === "J" && this.x < 50 && rotation === 2) {
      this.x = 50;
    } else if (this.currentBlockType === "L" && this.x < 70 && rotation === 2) {
      this.x = 70;
    } else if (this.currentBlockType === "T" && this.x < 70 && rotation === 2) {
      this.x = 70;
    } else if (this.currentBlockType === "I" && this.x < 50 && rotation === 2) {
      this.x = 50;
    } else if (this.currentBlockType === "O" && this.x < 70 && rotation === 2) {
      this.x = 70;
    }

    //ROTATION 3
    if (this.x < 30 && rotation === 3) {
      this.x = 30;
    } else if (this.currentBlockType === "S" && this.x < 50 && rotation === 3) {
      this.x = 50;
    } else if (this.currentBlockType === "Z" && this.x < 50 && rotation === 3) {
      this.x = 50;
    } else if (this.currentBlockType === "J" && this.x < 30 && rotation === 3) {
      this.x = 30;
    } else if (this.currentBlockType === "L" && this.x < 30 && rotation === 3) {
      this.x = 30;
    } else if (this.currentBlockType === "T" && this.x < 30 && rotation === 3) {
      this.x = 30;
    } else if (this.currentBlockType === "I" && this.x < 30 && rotation === 3) {
      this.x = 30;
    } else if (this.currentBlockType === "O" && this.x < 30 && rotation === 3) {
      this.x = 30;
    }

    //RIGHT SIDE
    //ROTATION 0
    if (this.x > 210 && rotation === 0) {
      this.x = 210;
    } else if (this.currentBlockType === "Z" && this.x > 190 && rotation === 0) {
      this.x = 190;
    } else if (this.currentBlockType === "T" && this.x > 190 && rotation === 0) {
      this.x = 190;
    } else if (this.currentBlockType === "L" && this.x > 190 && rotation === 0) {
      this.x = 190;
    } else if (this.currentBlockType === "O" && this.x > 190 && rotation === 0) {
      this.x = 190;
    }

    //ROTATION 1
    if (this.currentBlockType === "Z" && this.x > 210 && rotation === 1) {
      this.x = 210;
    } else if (this.currentBlockType === "T" && this.x > 230 && rotation === 1) {
      this.x = 230;
    } else if (this.currentBlockType === "L" && this.x > 230 && rotation === 1) {
      this.x = 230;
    } else if (this.currentBlockType === "O" && this.x > 230 && rotation === 1) {
      this.x = 230;
    } else if (this.currentBlockType === "J" && this.x > 230 && rotation === 1) {
      this.x = 230;
    } else if (this.currentBlockType === "I" && this.x > 230 && rotation === 1) {
      this.x = 230;
    } else if (this.currentBlockType === "S" && this.x > 210 && rotation === 1) {
      this.x = 210;
    }
    
    //ROTATION 2
    if (this.currentBlockType === "Z" && this.x > 230 && rotation === 2) {
      this.x = 230;
    } else if (this.currentBlockType === "T" && this.x > 210 && rotation === 2) {
      this.x = 210;
    } else if (this.currentBlockType === "L" && this.x > 230 && rotation === 2) {
      this.x = 230;
    } else if (this.currentBlockType === "O" && this.x > 230 && rotation === 2) {
      this.x = 230;
    } else if (this.currentBlockType === "J" && this.x > 210 && rotation === 2) {
      this.x = 210;
    } else if (this.currentBlockType === "I" && this.x > 230 && rotation === 2) {
      this.x = 230;
    } else if (this.currentBlockType === "S" && this.x > 210 && rotation === 2) {
      this.x = 210;
    }

    //ROTATION 3
    if (this.currentBlockType === "Z" && this.x > 190 && rotation === 3) {
      this.x = 190;
    } else if (this.currentBlockType === "T" && this.x > 190 && rotation === 3) {
      this.x = 190;
    } else if (this.currentBlockType === "L" && this.x > 170 && rotation === 3) {
      this.x = 170;
    } else if (this.currentBlockType === "O" && this.x > 190 && rotation === 3) {
      this.x = 190;
    } else if (this.currentBlockType === "J" && this.x > 170 && rotation === 3) {
      this.x = 170;
    } else if (this.currentBlockType === "I" && this.x > 150 && rotation === 3) {
      this.x = 150;
    } else if (this.currentBlockType === "S" && this.x > 190 && rotation === 3) {
      this.x = 190;
    }

    //BOTTOM BOUNDARIES
    if (this.y > 330 && rotation === 0) {
      this.y = 330;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "I" && this.y > 290 && rotation === 0) {
      this.y = 290;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "J" && this.y > 310 && rotation === 0) {
      this.y = 310;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "L" && this.y > 310 && rotation === 0) {
      this.y = 310;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "Z" && this.y > 310 && rotation === 0) {
      this.y = 330;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "S" && this.y > 310 && rotation === 0) {
      this.y = 330;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "O" && this.y > 310 && rotation === 0) {
      this.y = 330;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "T" && this.y > 310 && rotation === 0) {
      this.y = 330;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    }
    //Rotation 1
    if (this.currentBlockType === "I" && this.y > 350 && rotation === 1) {
      this.y = 350;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "J" && this.y > 350 && rotation === 1) {
      this.y = 350;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "L" && this.y > 330 && rotation === 1) {
      this.y = 330;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "Z" && this.y > 330 && rotation === 1) {
      this.y = 330;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "S" && this.y > 350 && rotation === 1) {
      this.y = 350;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "O" && this.y > 310 && rotation === 1) {
      this.y = 330;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "T" && this.y > 310 && rotation === 1) {
      this.y = 330;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    }
    //Rotation 2
    if (this.currentBlockType === "Z" && this.y > 350 && rotation === 2) {
      this.y = 350;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "S" && this.y > 350 && rotation === 2) {
      this.y = 350;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "O" && this.y > 370 && rotation === 2) {
      this.y = 370;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    }  else if (this.currentBlockType === "T" && this.y > 370 && rotation === 2) {
      this.y = 370;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "I" && this.y > 370 && rotation === 2) { 
      this.y = 370;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "J" && this.y > 370 && rotation === 2) {
      this.y = 370;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "L" && this.y > 370 && rotation === 2) {
      this.y = 370;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    }
    //Rotation 3
    if (this.currentBlockType === "Z" && this.y > 369 && rotation === 3) {
      this.y = 370
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "S" && this.y > 350 && rotation === 3) {
      this.y = 350;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "O" && this.y > 370 && rotation === 3) {
      this.y = 370;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "T" && this.y > 350 && rotation === 3) {
      this.y = 350;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "I" && this.y > 370 && rotation === 3) {
      this.y = 370;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "J" && this.y > 350 && rotation === 3) {
      this.y = 350;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
    } else if (this.currentBlockType === "L" && this.y > 370 && rotation === 3) {
      this.y = 370;
      if (this.activeBlock === true) {
        blockPlaced = true;
        this.activeBlock = false;
      }
   }
   }
  }
  /*
  *Checking for collisions with other blocks
  */
  isColliding() {
    //work on later
   }
}

var currentScreen = 0,
  button1, button2, score, lines,
  buttonX = [100, 100, 20],
  buttonY = [175, 250, 340],
  buttonW = [200, 200, 80],
  buttonH = [50, 50, 40],
  blockX = 110,
  score = 000000,
  blockY = 50,
  rotAngle = 0,
  rotation = 0,
  blockAmount = 0,
  lineAmount = 0,
  levelAmount = 0,
  showNext = true,
  blockPlaced = true,
  blockTypes = ["I", "O", "T", "S", "Z", "J", "L"],
  blocks = [];

/*
 * Checks, Manages and creates blocks
 * Returns blockAmount
 */
function keepTrackOfBlocks() {
  if (blockPlaced === true) {
    if (blocks.length > 0) {
    score += 50;
    }
    blocks.push(new Block(blockX, blockY, rotAngle));
    rotation = 0;
    blockPlaced = false;
  }
  return blockAmount;
}
/*
 * Dropping blocks down playfield
 * i is what the current block is
 */
function moveBlockDown(i) {
    //dropping the block every 30 frames (1 sec) until it reaches bottom of playfield
    //ROTATION 0
    if (blocks[i].y <= 310 && rotation === 0 && blocks[i].activeBlock === true) {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } //ROTATION 1
    else if (blocks[i].y <= 350 && rotation === 1 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "I") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 390 && rotation === 1 && blocks[i].activeBlock === true  && blocks[i].currentBlockType === "S") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 390 && rotation === 1 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "Z") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 350 && rotation === 1 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "L") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 370 && rotation === 1 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "J") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } 
    //ROTATION 2
    if (blocks[i].y <= 370 && rotation === 2 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "I") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 350 && rotation === 2 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "Z") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 350 && rotation === 2 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "S") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 370 && rotation === 2 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "O") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 370 && rotation === 2 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "T") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 370 && rotation === 2 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "J") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 370 && rotation === 2 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "L") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    }
  //ROTATION 3
    if (blocks[i].y <= 370 && rotation === 3 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "I") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 370 && rotation === 3 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "Z") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 370 && rotation === 3 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "S") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 370 && rotation === 3 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "O") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 370 && rotation === 3 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "T") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 370 && rotation === 3 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "J") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    } else if (blocks[i].y <= 370 && rotation === 3 && blocks[i].activeBlock === true && blocks[i].currentBlockType === "L") {
      if (frameCount % 30 === 0) {
        blocks[i].y += 20;
      }
    }
}

/*
 * Draws thumbnails for next block
 * i is what the current block is
 */
function drawThumbs(i) {
  push();
  fill(200);
  rect(280, 80, 75, 75);
  noStroke();
  if (blocks[i].nextBlockType === "I") {
    fill(0, 255, 153);
    rect(308, 88, 15, 60);
  } else if (blocks[i].nextBlockType === "O") {
    fill(255, 204, 0);
    rect(300, 100, 40, 40);
  } else if (blocks[i].nextBlockType === "T") {
    fill(153, 0, 153);
    rect(308, 102, 20, 40);
    rect(288, 102, 60, 20);
  } else if (blocks[i].nextBlockType === "S") {
    fill(0, 204, 0);
    rect(295, 90, 20, 40);
    rect(315, 110, 20, 40);  
  } else if (blocks[i].nextBlockType === "Z") {
    fill(255, 0, 0);
    rect(315, 90, 20, 40);
    rect(295, 110, 20, 40);
  } else if (blocks[i].nextBlockType === "J") {
    fill(0, 0, 255);
    rect(315, 90, 20, 60);
    rect(295, 130, 20, 20);  
  } else if (blocks[i].nextBlockType === "L") {
    fill(255, 153, 0);
    rect(300, 90, 20, 60);
    rect(320, 130, 20, 20);
  } 
  pop();
}

//Draws the main menu
function drawMenu() {
  push();
  background(255, 132, 80);
  fill(0);
  textSize(26);
  textStyle(BOLD);
  textFont("Courier New");
  textAlign(CENTER);
  text("<TETRIS>", 200, 100);
  fill(200);
  if (mouseY > 175 && mouseY < 225 && mouseX > 100 && mouseX < 300) {
    fill(100);
  }
  button1 = rect(buttonX[0], buttonY[0], buttonW[0], buttonH[0]);
  fill(200);
  if (mouseY > 250 && mouseY < 300 && mouseX > 100 && mouseX < 300) {
    fill(100);
  }
  button2 = rect(buttonX[1], buttonY[1], buttonW[1], buttonH[1]);  
  fill(0);
  text("Instructions", 200, 208);
  text("Play", 200, 282);
  textSize(13);
  text("2019 Anthony Ormerod", 90, 382);
  pop();
}

/*
 * Draws the game mode select
 */
function drawGameSelect() {
  push();
  background(255, 132, 80);
  fill(0);
  textSize(26);
  textStyle(BOLD);
  textFont("Courier New");
  textAlign(CENTER);
  text("Difficulty", 200, 100);
  fill(200);
  if (mouseY > 175 && mouseY < 225 && mouseX > 100 && mouseX < 300) {
    fill(100);
  }
  button1 = rect(buttonX[0], buttonY[0], buttonW[0], buttonH[0]);
  fill(200);
  if (mouseY > 250 && mouseY < 300 && mouseX > 100 && mouseX < 300) {
    fill(100);
  }
  button2 = rect(buttonX[1], buttonY[1], buttonW[1], buttonH[1]);  
  fill(0);
  text("Easy", 200, 208);
  text("Hard", 200, 282);
  textStyle(BOLD);
  textSize(20);
  fill(200);
  if (mouseY > 340 && mouseY < 380 && mouseX > 20 && mouseX < 100) {
    fill(100);
  }
  textStyle(BOLD);
  textSize(20);
  rect(buttonX[2], buttonY[2], buttonW[2], buttonH[2]);
  fill(0);
  text("Back", 60, 366);
  pop();
}

/*
 * Draws the instructions
 */
function drawInstructions() {
  push();
  textAlign(CENTER);
  textStyle(BOLD);
  textSize(16);
  background(255, 132, 80);
  fill(0);
  text("Tetris is a puzzle game created by \nRussian Alexey Pajitnov in 1984. \nIn Tetris, you have to stack and fit \nblocks together to get points.\n\nYou can eliminate block rows by\nconnecting blocks horizontally.\n\nTo move blocks left and right, \nuse the left/right arrow keys.\n\nTo flip blocks, use space bar or up key.", 200, 70); 
  fill(200);
  if (mouseY > 340 && mouseY < 380 && mouseX > 20 && mouseX < 100) {
    fill(100);
  }
  textStyle(BOLD);
  textSize(20);
  rect(buttonX[2], buttonY[2], buttonW[2], buttonH[2]);
  fill(0);
  text("Back", 60, 366);
  pop();
}

/*
 * Draws the level
 */
function drawLevel() {
  //logs amount of blocks on screen
  if (blockPlaced === true) {
    console.log(keepTrackOfBlocks());
  }
  //Block management
  keepTrackOfBlocks();
  //The screen and playfield itself
  stroke(0);
  background(12, 144, 235);
  fill(200);
  rect(29, 30, 201, 340);
  for (let i = 0; i < blocks.length; i++) {
    drawThumbs(i);
  }
  fill(0);
  textSize(20);
  text("<TETRIS>", 270, 55);
  text("SCORE:", 283, 190);
  text(score, 283, 215);
  text("LINES:", 283, 240);
  text(lineAmount, 283, 265);
  text("LEVEL:", 283, 290);
  text(levelAmount, 283, 315);
  //Draws the block/rotates
  for (let i = 0; i < blocks.length; i++) {
    //Draw next block previews

    //Move blocks vertically
    moveBlockDown(i);
    //Defines boundaries of the current block
    blocks[i].defineBoundaries();
    blocks[i].draw(blocks[i].rotAngle);
  }
}

function keyPressed() {
  for (let i = 0; i < blocks.length; i++) {
    if (blocks[i].activeBlock === true) {
      //Left Arrow Key
      if (keyCode === LEFT_ARROW) {
        blocks[i].x -= 20;
      }
      //Right Arrow Key
      if (keyCode === RIGHT_ARROW) {
        blocks[i].x += 20;
      }
      //Down Arrow Key
      if (keyCode === DOWN_ARROW) {
        blocks[i].y += 20;
      }
      //Up Arrow Key or Spacebar
      if (keyCode === UP_ARROW || key == " ") {
        //Increases rotation angle by 90
        blocks[i].rotAngle += 90;
        //Keeping track of the block's current rotation
        rotation++;
        if (rotation > 3) {
          rotation = 0;
        }
      }
    }
  }
}

function mousePressed() {
  if (currentScreen === 1) {
  if (mouseY > 175 && mouseY < 225 && mouseX > 100 && mouseX < 300) {
    currentScreen = 3;
    console.log(currentScreen);
  }
  if (mouseY > 250 && mouseY < 300 && mouseX > 100 && mouseX < 300) {
    currentScreen = 3;
    console.log(currentScreen);
  }
  }
  if (currentScreen === 0) {
  if (mouseY > 175 && mouseY < 225 && mouseX > 100 && mouseX < 300) {
    currentScreen = 2;
    console.log(currentScreen);
  }
  if (mouseY > 250 && mouseY < 300 && mouseX > 100 && mouseX < 300) {
    currentScreen = 1;
    console.log(currentScreen);
  }
  } else if (currentScreen === 2 || currentScreen === 1) {
  if (mouseY > 340 && mouseY < 380 && mouseX > 20 && mouseX < 100) {
    currentScreen = 0;
    console.log(currentScreen);
  }
  }
}

function setup() {
  createCanvas(400, 400);
  frameRate(30);
  angleMode(DEGREES);
  textFont("Courier New");
}

function draw() {
  if (currentScreen === 0) {
    drawMenu();
  } else if (currentScreen === 1) {
    drawGameSelect();
  } else if(currentScreen === 2) {
   drawInstructions();
 } else if (currentScreen === 3) {
   drawLevel();
  }
}
